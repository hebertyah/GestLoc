window.APP_CONFIG = {
  appName: 'LocaControl',
  storageMode: 'local-demo',
  apiBaseUrl: '',
  supabaseUrl: '',
  supabaseAnonKey: ''
};
