const CONFIG = window.APP_CONFIG || {};
const state = {
  clientes: [
    { id: 1, nome: 'Maria Aparecida', tel: '(38) 99123-4567', doc: '123.456.789-00', end: 'Rua das Flores, 12', email: '', obs: '' },
    { id: 2, nome: 'José Carlos', tel: '(38) 99876-5432', doc: '987.654.321-00', end: 'Av. Principal, 55', email: '', obs: '' }
  ],
  equips: [
    { id: 1, nome: 'Betoneira 400L', cod: 'EQ-001', cat: 'Construção Civil', valor: 120, desc: 'Capacidade 400 litros' },
    { id: 2, nome: 'Compactador de Solo', cod: 'EQ-002', cat: 'Construção Civil', valor: 180, desc: 'Sapo compactador' },
    { id: 3, nome: 'Andaime 6m', cod: 'EQ-003', cat: 'Construção Civil', valor: 60, desc: 'Kit com 3 pranchas' },
    { id: 4, nome: 'Roçadeira', cod: 'EQ-004', cat: 'Jardinagem', valor: 80, desc: 'Elétrica bivolt' }
  ],
  locs: [
    { id: 1, eid: 1, cid: 1, data: '2026-04-01', prev: '2026-04-08', obs: 'Retirado às 9h' },
    { id: 2, eid: 3, cid: 2, data: '2026-04-03', prev: '', obs: '' }
  ],
  hist: [],
  nc: 3,
  ne: 5,
  nl: 3
};

const $ = (id) => document.getElementById(id);
const gc = (id) => state.clientes.find((c) => c.id === id);
const ge = (id) => state.equips.find((e) => e.id === id);
const isLoc = (eid) => state.locs.some((l) => l.eid === eid);
const fmtD = (d) => d ? `${d.split('-')[2]}/${d.split('-')[1]}/${d.split('-')[0]}` : '—';
const today = () => new Date().toISOString().slice(0, 10);
const diffD = (a, b) => Math.round((new Date(b) - new Date(a)) / 86400000);
let currentView = 'dashboard';
let eqTab = 'todos';
let selectedDevId = null;

function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.style.cssText = 'transform:translateY(0);opacity:1;';
  setTimeout(() => { t.style.cssText = 'transform:translateY(100px);opacity:0;'; }, 2500);
}

function openModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }

function setupTheme() {
  const root = document.documentElement;
  const btn = document.querySelector('[data-theme-toggle]');
  let mode = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  root.setAttribute('data-theme', mode);
  btn?.addEventListener('click', () => {
    mode = mode === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', mode);
  });
}

function go(view) {
  currentView = view;
  document.querySelectorAll('.view').forEach((el) => el.classList.remove('active'));
  $(`view-${view}`).classList.add('active');
  document.querySelectorAll('.nav-item').forEach((el) => el.classList.toggle('active', el.dataset.view === view));
  document.querySelectorAll('.mob-tab').forEach((el) => el.classList.toggle('active', el.dataset.view === view));
  $('page-title').textContent = ({ dashboard: 'Dashboard', clientes: 'Clientes', equipamentos: 'Equipamentos', locacoes: 'Locações Ativas', historico: 'Histórico' })[view];
  renderActions(view);
  renderView(view);
}

function renderActions(view) {
  const a = $('page-actions');
  if (view === 'clientes') a.innerHTML = '<button class="btn btn-primary btn-sm" id="btn-novo-cliente"><i data-lucide="user-plus"></i><span>Novo Cliente</span></button>';
  else if (view === 'equipamentos') a.innerHTML = '<button class="btn btn-ghost btn-sm" id="btn-nova-locacao" style="margin-right:4px"><i data-lucide="clipboard-plus"></i><span>Alocar</span></button><button class="btn btn-primary btn-sm" id="btn-novo-equip"><i data-lucide="plus"></i><span>Novo Equip.</span></button>';
  else if (view === 'locacoes') a.innerHTML = '<button class="btn btn-primary btn-sm" id="btn-nova-locacao"><i data-lucide="clipboard-plus"></i><span>Nova Locação</span></button>';
  else a.innerHTML = '';
  bindDynamicActions();
  lucide.createIcons();
}

function renderView(view) {
  if (view === 'dashboard') renderDash();
  if (view === 'clientes') renderClientes();
  if (view === 'equipamentos') renderEqs();
  if (view === 'locacoes') renderLocs();
  if (view === 'historico') renderHist();
}

function renderDash() {
  $('s-cli').textContent = state.clientes.length;
  $('s-loc').textContent = state.locs.length;
  $('s-eq').textContent = state.equips.length;
  $('s-dsp').textContent = state.equips.filter((e) => !isLoc(e.id)).length;
  const tb = $('dash-tb');
  if (!state.locs.length) tb.innerHTML = '<tr><td colspan="4">Sem locações</td></tr>';
  else tb.innerHTML = [...state.locs].reverse().slice(0, 6).map((l) => {
    const eq = ge(l.eid), cl = gc(l.cid);
    return `<tr><td><strong>${eq?.nome || '?'}</strong></td><td>${cl?.nome || '?'}</td><td class="td-m">${fmtD(l.data)}</td><td><span class="badge b-green">Ativo</span></td></tr>`;
  }).join('');
  lucide.createIcons();
}

function renderClientes() {
  const q = $('srch-cli').value.toLowerCase();
  const list = state.clientes.filter((c) => c.nome.toLowerCase().includes(q) || c.tel.includes(q) || c.doc.includes(q));
  const tb = $('cli-tb');
  tb.innerHTML = list.length ? list.map((c) => {
    const qtd = state.locs.filter((l) => l.cid === c.id).length;
    return `<tr><td><strong>${c.nome}</strong><br><span class="td-m" style="font-size:var(--xs)">${c.end || ''}</span></td><td class="td-m">${c.tel || '—'}</td><td class="td-m">${c.doc || '—'}</td><td>${qtd ? `<span class="badge b-green">${qtd} ativo${qtd > 1 ? 's' : ''}</span>` : '<span class="badge b-gray">0</span>'}</td><td><button class="btn btn-ghost btn-sm act-edit-cli" data-id="${c.id}"><i data-lucide="pencil"></i></button> <button class="btn btn-danger btn-sm act-del-cli" data-id="${c.id}"><i data-lucide="trash-2"></i></button></td></tr>`;
  }).join('') : '<tr><td colspan="5">Nenhum cliente</td></tr>';
  lucide.createIcons();
}

function renderEqs() {
  let list = state.equips;
  if (eqTab === 'disp') list = list.filter((e) => !isLoc(e.id));
  if (eqTab === 'loc') list = list.filter((e) => isLoc(e.id));
  const g = $('eq-grid');
  g.innerHTML = list.length ? list.map((e) => {
    const l = state.locs.find((x) => x.eid === e.id), cl = l ? gc(l.cid) : null;
    return `<div class="equip-card"><div class="equip-head"><div><div class="equip-name">${e.nome}</div><div class="equip-code">${e.cod || 'S/cód'}${e.cat ? ` · ${e.cat}` : ''}</div></div><span class="badge ${l ? 'b-warn' : 'b-green'}">${l ? 'Locado' : 'Disponível'}</span></div><div class="equip-info">${e.desc ? `<span>${e.desc}</span>` : ''}${e.valor ? `<span>💵 R$ ${Number(e.valor).toFixed(2)}/dia</span>` : ''}${cl ? `<span style="color:var(--color-primary);font-weight:600">📌 ${cl.nome} — desde ${fmtD(l.data)}</span>` : ''}</div><div class="equip-foot">${!l ? `<button class="btn btn-primary btn-sm act-open-loc-eq" data-id="${e.id}"><i data-lucide="clipboard-plus"></i>Alocar</button>` : `<button class="btn btn-ghost btn-sm act-open-dev" data-id="${l.id}"><i data-lucide="package-check"></i>Devolver</button>`}<button class="btn btn-ghost btn-sm act-edit-eq" data-id="${e.id}"><i data-lucide="pencil"></i></button>${!l ? `<button class="btn btn-danger btn-sm act-del-eq" data-id="${e.id}"><i data-lucide="trash-2"></i></button>` : ''}</div></div>`;
  }).join('') : '<div>Nenhum equipamento</div>';
  lucide.createIcons();
}

function renderLocs() {
  const tb = $('loc-tb');
  const tod = today();
  tb.innerHTML = state.locs.length ? state.locs.map((l) => {
    const eq = ge(l.eid), cl = gc(l.cid), dias = diffD(l.data, tod), atrasado = l.prev && l.prev < tod;
    return `<tr><td><strong>${eq?.nome || '?'}</strong></td><td class="td-m">${eq?.cod || '?'}</td><td>${cl?.nome || '?'}</td><td class="td-m">${cl?.tel || '—'}</td><td class="td-m">${fmtD(l.data)}<br><span style="font-size:var(--xs)">${dias}d</span></td><td class="td-m">${fmtD(l.prev)}${atrasado ? ' <span class="badge b-red">Atrasado</span>' : ''}</td><td class="td-m" style="max-width:120px;white-space:normal;font-size:var(--xs)">${l.obs || '—'}</td><td><button class="btn btn-ghost btn-sm act-open-dev" data-id="${l.id}"><i data-lucide="package-check"></i>Devolver</button></td></tr>`;
  }).join('') : '<tr><td colspan="8">Nenhuma locação ativa</td></tr>';
  lucide.createIcons();
}

function renderHist() {
  const tb = $('hist-tb');
  tb.innerHTML = state.hist.length ? [...state.hist].reverse().map((h) => `<tr><td><strong>${h.en}</strong></td><td>${h.cn}</td><td class="td-m">${fmtD(h.dl)}</td><td class="td-m">${fmtD(h.dd)}</td><td><span class="badge b-blue">${diffD(h.dl, h.dd)}d</span></td></tr>`).join('') : '<tr><td colspan="5">Histórico vazio</td></tr>';
  lucide.createIcons();
}

function openCli(id) {
  $('f-cid').value = '';
  ['f-cn','f-ct','f-cd','f-ce','f-cm','f-co'].forEach((id) => $(id).value = '');
  $('m-cli-t').textContent = 'Novo Cliente';
  if (id) {
    const c = gc(id);
    $('f-cid').value = id;
    $('f-cn').value = c.nome; $('f-ct').value = c.tel; $('f-cd').value = c.doc; $('f-ce').value = c.end; $('f-cm').value = c.email; $('f-co').value = c.obs;
    $('m-cli-t').textContent = 'Editar Cliente';
  }
  openModal('m-cli');
}

function saveCli() {
  const nome = $('f-cn').value.trim();
  if (!nome) return alert('Informe o nome.');
  const id = Number($('f-cid').value);
  const obj = { nome, tel: $('f-ct').value.trim(), doc: $('f-cd').value.trim(), end: $('f-ce').value.trim(), email: $('f-cm').value.trim(), obs: $('f-co').value.trim() };
  if (id) Object.assign(gc(id), obj); else state.clientes.push({ id: state.nc++, ...obj });
  closeModal('m-cli'); renderClientes(); renderDash(); toast(id ? 'Cliente atualizado!' : 'Cliente cadastrado!');
}

function delCli(id) {
  if (!confirm('Excluir cliente?')) return;
  if (state.locs.some((l) => l.cid === id)) return alert('Cliente tem locações ativas.');
  state.clientes = state.clientes.filter((c) => c.id !== id);
  renderClientes(); renderDash(); toast('Cliente excluído.');
}

function openEq(id) {
  $('f-eid').value = '';
  ['f-en','f-ec','f-ecat','f-ev','f-ed'].forEach((id) => $(id).value = '');
  $('m-eq-t').textContent = 'Novo Equipamento';
  if (id) {
    const e = ge(id);
    $('f-eid').value = id; $('f-en').value = e.nome; $('f-ec').value = e.cod; $('f-ecat').value = e.cat; $('f-ev').value = e.valor; $('f-ed').value = e.desc;
    $('m-eq-t').textContent = 'Editar Equipamento';
  }
  openModal('m-eq');
}

function saveEq() {
  const nome = $('f-en').value.trim();
  if (!nome) return alert('Informe o nome.');
  const id = Number($('f-eid').value);
  const obj = { nome, cod: $('f-ec').value.trim(), cat: $('f-ecat').value, valor: Number($('f-ev').value) || 0, desc: $('f-ed').value.trim() };
  if (id) Object.assign(ge(id), obj); else state.equips.push({ id: state.ne++, ...obj });
  closeModal('m-eq'); renderEqs(); renderDash(); toast(id ? 'Equipamento atualizado!' : 'Equipamento cadastrado!');
}

function delEq(id) {
  if (!confirm('Excluir equipamento?')) return;
  state.equips = state.equips.filter((e) => e.id !== id);
  renderEqs(); renderDash(); toast('Equipamento excluído.');
}

function fillSels(fixEid) {
  const disp = state.equips.filter((e) => !isLoc(e.id));
  $('f-le').innerHTML = `<option value="">Selecione...</option>${disp.map((e) => `<option value="${e.id}">${e.nome}${e.cod ? ` (${e.cod})` : ''}</option>`).join('')}`;
  $('f-lc').innerHTML = `<option value="">Selecione...</option>${state.clientes.map((c) => `<option value="${c.id}">${c.nome}</option>`).join('')}`;
  if (fixEid) $('f-le').value = fixEid;
}

function openLoc(fixEid) {
  fillSels(fixEid);
  $('f-ld').value = today(); $('f-lp').value = ''; $('f-lo').value = '';
  openModal('m-loc');
}

function saveLoc() {
  const eid = Number($('f-le').value), cid = Number($('f-lc').value), data = $('f-ld').value;
  if (!eid || !cid || !data) return alert('Preencha equipamento, cliente e data.');
  state.locs.push({ id: state.nl++, eid, cid, data, prev: $('f-lp').value, obs: $('f-lo').value.trim() });
  closeModal('m-loc'); renderView(currentView); renderDash(); toast('Locação registrada!');
}

function openDev(id) {
  selectedDevId = id;
  const l = state.locs.find((x) => x.id === id);
  $('dev-en').textContent = ge(l.eid)?.nome || '?';
  $('dev-cn').textContent = gc(l.cid)?.nome || '?';
  $('f-dd').value = today();
  openModal('m-dev');
}

function confirmDev() {
  const l = state.locs.find((x) => x.id === selectedDevId);
  if (!l) return;
  const dd = $('f-dd').value || today();
  state.hist.push({ en: ge(l.eid)?.nome || '?', cn: gc(l.cid)?.nome || '?', dl: l.data, dd });
  state.locs = state.locs.filter((x) => x.id !== selectedDevId);
  closeModal('m-dev'); renderView(currentView); renderDash(); toast('Devolução registrada!');
}

function bindDynamicActions() {
  $('btn-novo-cliente')?.addEventListener('click', () => openCli());
  $('btn-novo-equip')?.addEventListener('click', () => openEq());
  document.querySelectorAll('#btn-nova-locacao').forEach((el) => el.addEventListener('click', () => openLoc()));
}

function bindStaticEvents() {
  document.querySelectorAll('.nav-item,.mob-tab').forEach((el) => el.addEventListener('click', () => go(el.dataset.view)));
  document.querySelectorAll('[data-go]').forEach((el) => el.addEventListener('click', () => go(el.dataset.go)));
  document.querySelectorAll('[data-close]').forEach((el) => el.addEventListener('click', () => closeModal(el.dataset.close)));
  $('srch-cli').addEventListener('input', renderClientes);
  document.querySelectorAll('.tab').forEach((el) => el.addEventListener('click', () => { eqTab = el.dataset.tab; document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active')); el.classList.add('active'); renderEqs(); }));
  $('save-cli').addEventListener('click', saveCli);
  $('save-eq').addEventListener('click', saveEq);
  $('save-loc').addEventListener('click', saveLoc);
  $('confirm-dev').addEventListener('click', confirmDev);
  document.body.addEventListener('click', (e) => {
    const btn = e.target.closest('button');
    if (!btn) return;
    if (btn.classList.contains('act-edit-cli')) openCli(Number(btn.dataset.id));
    if (btn.classList.contains('act-del-cli')) delCli(Number(btn.dataset.id));
    if (btn.classList.contains('act-edit-eq')) openEq(Number(btn.dataset.id));
    if (btn.classList.contains('act-del-eq')) delEq(Number(btn.dataset.id));
    if (btn.classList.contains('act-open-loc-eq')) openLoc(Number(btn.dataset.id));
    if (btn.classList.contains('act-open-dev')) openDev(Number(btn.dataset.id));
  });
}

function boot() {
  console.log(`%c${CONFIG.appName || 'LocaControl'} iniciado em modo ${CONFIG.storageMode || 'local-demo'}`, 'color:#01696f;font-weight:bold;');
  setupTheme();
  bindStaticEvents();
  renderDash();
  renderActions('dashboard');
  lucide.createIcons();
}

boot();
